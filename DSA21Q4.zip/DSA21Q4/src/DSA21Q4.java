import java.util.LinkedList;
import java.util.Queue;

class Node {
    int data;
    Node left, right, nextRight;

    public Node(int item) {
        data = item;
        left = right = nextRight = null;
    }
}

public class DSA21Q4 {
    Node root;

    void connectNodes(Node node) {
        Queue<Node> queue = new LinkedList<>();
        queue.add(node);
        queue.add(null);

        while (!queue.isEmpty()) {
            Node currNode = queue.poll();

            if (currNode != null) {
                currNode.nextRight = queue.peek();

                if (currNode.left != null)
                    queue.add(currNode.left);

                if (currNode.right != null)
                    queue.add(currNode.right);
            } else if (!queue.isEmpty()) {
                queue.add(null);
            }
        }
    }

    void printLevelOrderTraversal(Node node) {
        if (node == null)
            return;

        while (node != null) {
            Node temp = node;
            while (temp != null) {
                System.out.print(temp.data + " -> ");
                temp = temp.nextRight;
            }
            System.out.println("-1");
            node = node.left;
        }
    }

    public static void main(String args[]) {
    	DSA21Q4 tree = new DSA21Q4();
        tree.root = new Node(1);
        tree.root.left = new Node(2);
        tree.root.right = new Node(3);
        tree.root.left.left = new Node(4);
        tree.root.left.right = new Node(5);
        tree.root.right.left = new Node(6);
        tree.root.right.right = new Node(7);

        tree.connectNodes(tree.root);
        tree.printLevelOrderTraversal(tree.root);
    }
}
